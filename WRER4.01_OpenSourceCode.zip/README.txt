Jesli to czytasz, masz source code WRER'a.

Poniżej znajdziesz ponizsze informacje.

- Autorem jest: Windows_Locker (DISCORD: Zpizgany Jerry#9690)
- Prosze nie zmieniac WRER'a w wirusa, poniewaz to jest oprogramowanie ktore resetuje klucze w rejestrze.
- Mam gdzieś co zrobisz z tym kodem zrodlowym.

- Umieść folder WRER4.01 w tej lokalizacji: C:\Users\{TWÓJ_UZYTKOWNIK}\source\repos

PRZETESTOWANE PRZEZ:

DaVinci
--------------------------------------------------------------
HASLO DO KODU ZRODLOWEGO WRERA:
WRER4_01_SourceCode